(function () {
  function debounce(fn, ms) {
    var t;
    return function () {
      clearTimeout(t);
      var args = arguments;
      var self = this;
      t = setTimeout(function () {
        fn.apply(self, args);
      }, ms);
    };
  }

  function resizeCharts() {
    try {
      if (typeof Chart !== "undefined") {
        if (typeof Chart.getChart === "function") {
          document.querySelectorAll("canvas").forEach(function (el) {
            var c = Chart.getChart(el);
            if (c) c.resize();
          });
        } else if (Chart.instances) {
          Object.values(Chart.instances).forEach(function (c) {
            if (c && c.resize) c.resize();
          });
        }
      }
    } catch (e) {}
  }

  function wireIframeLogoToggle() {
    if (window.self === window.top) return;
    var btn = document.querySelector("header .dash-header-logo-btn");
    if (!btn) {
      var img = document.querySelector("header .brandLogo");
      if (!img) return;
      btn = document.createElement("button");
      btn.type = "button";
      btn.className = "dash-header-logo-btn";
      img.parentNode.insertBefore(btn, img);
      btn.appendChild(img);
    }
    btn.setAttribute("aria-expanded", "false");
    btn.setAttribute("title", "คลิกโลโก้เพื่อแสดง/ซ่อนเมนู");

    btn.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();
      try {
        window.parent.postMessage("fda-dash-toggle-sidebar", "*");
      } catch (e2) {}
    });
  }

  function init() {
    wireIframeLogoToggle();
    window.addEventListener("load", resizeCharts);
    window.addEventListener("resize", debounce(resizeCharts, 120));
  }

  window.dashLayoutResize = resizeCharts;

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
