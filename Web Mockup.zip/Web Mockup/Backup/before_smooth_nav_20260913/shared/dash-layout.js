(function () {
  function debounce(fn, ms) {
    var t;
    return function () {
      clearTimeout(t);
      var args = arguments;
      var self = this;
      t = setTimeout(function () {
        fn.apply(self, args);
      }, ms);
    };
  }

  function resizeChartsAndMaps() {
    try {
      if (typeof Chart !== "undefined") {
        if (typeof Chart.getChart === "function") {
          document.querySelectorAll("canvas").forEach(function (el) {
            var c = Chart.getChart(el);
            if (c) c.resize();
          });
        } else if (Chart.instances) {
          Object.values(Chart.instances).forEach(function (c) {
            if (c && c.resize) c.resize();
          });
        }
      }
    } catch (e) {}
    try {
      if (window.mapObj && window.mapObj.invalidateSize) window.mapObj.invalidateSize(true);
    } catch (e2) {}
    window.dispatchEvent(new Event("dash-layout-resize"));
  }

  function runEnterAnimation() {
    var page = document.querySelector(".dash-page");
    if (!page || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    page.classList.add("dash-page-enter");
    requestAnimationFrame(function () {
      page.classList.add("dash-page-enter-active");
      setTimeout(function () {
        page.classList.remove("dash-page-enter", "dash-page-enter-active");
      }, 320);
    });
  }

  function wireIframeLogoToggle() {
    if (window.self === window.top) return;
    var img = document.querySelector("header .brandLogo");
    if (!img || img.closest(".dash-header-logo-btn")) return;

    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = "dash-header-logo-btn";
    btn.setAttribute("aria-expanded", "false");
    btn.setAttribute("title", "คลิกโลโก้เพื่อแสดง/ซ่อนเมนู");

    var parent = img.parentNode;
    parent.insertBefore(btn, img);
    btn.appendChild(img);

    btn.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();
      try {
        window.parent.postMessage("fda-dash-toggle-sidebar", "*");
      } catch (e2) {}
    });
  }

  function init() {
    wireIframeLogoToggle();
    window.addEventListener("load", resizeChartsAndMaps);
    window.addEventListener("resize", debounce(resizeChartsAndMaps, 120));
    window.addEventListener("dash-layout-resize", debounce(resizeChartsAndMaps, 80));
    if (document.readyState === "complete") runEnterAnimation();
    else window.addEventListener("load", runEnterAnimation);
    setTimeout(resizeChartsAndMaps, 400);
    setTimeout(resizeChartsAndMaps, 900);
  }

  window.dashLayoutResize = resizeChartsAndMaps;

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
