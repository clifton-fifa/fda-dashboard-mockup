(function () {
  if (window.self !== window.top) return;

  var DASH_ITEMS = [
    { n: 1, label: "ภาพรวมเศรษฐกิจผลิตภัณฑ์สุขภาพ" },
    { n: 2, label: "การวิเคราะห์โอกาสทางเศรษฐกิจ" },
    { n: 3, label: "การวิเคราะห์ผลิตภัณฑ์ดาวรุ่ง" },
    { n: 4, label: "การวิเคราะห์คอขวดด้านการกำกับดูแล" },
    { n: 5, label: "เมทริกซ์โอกาสเชิงกฎระเบียบ" },
    { n: 6, label: "การวิเคราะห์ผู้ประกอบการที่มีศักยภาพ" },
    { n: 7, label: "ข้อมูลเชิงลึกรายผลิตภัณฑ์" },
    { n: 8, label: "ข้อเสนอเชิงนโยบายและการจำลองสถานการณ์" },
    { n: 9, label: "แผนที่วิเคราะห์เชิงพื้นที่" },
    { n: 10, label: "การติดตามคุณภาพข้อมูลและธรรมาภิบาลข้อมูล" }
  ];

  var STORAGE_KEY = "fdaDashSidebarCollapsed";
  var suppressHashNav = false;

  function isShell() {
    return document.body && document.body.hasAttribute("data-dash-shell");
  }

  function detectDashNum() {
    if (isShell()) return dashNumFromHash();
    var fromBody = document.body && document.body.getAttribute("data-dash");
    if (fromBody) return parseInt(fromBody, 10);
    var m = (location.pathname || "").match(/d(\d+)(?:_NEW)?\.html/i);
    if (m) return parseInt(m[1], 10);
    return 1;
  }

  function dashNumFromHash() {
    var h = (location.hash || "#dash1").replace(/^#/, "");
    var m = h.match(/^dash(\d+)$/i);
    return m ? parseInt(m[1], 10) : 1;
  }

  function dashNumFromHref(href) {
    if (!href) return 0;
    var m = href.match(/d(\d+)(?:_NEW)?\.html/i);
    return m ? parseInt(m[1], 10) : 0;
  }

  function inDashboardsFolder() {
    return /\/dashboards\//i.test(location.pathname || "");
  }

  function hrefForDash(n) {
    if (n === 1) return inDashboardsFolder() ? "d1.html" : "d1_NEW.html";
    return "d" + n + ".html";
  }

  function sidebarCssHref() {
    var scripts = document.getElementsByTagName("script");
    for (var i = 0; i < scripts.length; i++) {
      var src = scripts[i].getAttribute("src") || "";
      if (src.indexOf("dash-sidebar.js") !== -1) {
        return src.replace(/dash-sidebar\.js.*$/, "dash-sidebar.css");
      }
    }
    return "shared/dash-sidebar.css";
  }

  function ensureStyles() {
    /* ใช้ <link> ใน HTML เป็นหลัก — ขนาดเมนูฐาน d1 จาก dash-sidebar.css */
    if (document.querySelector('link[data-dash-sidebar="1"]') || document.querySelector('link[href*="dash-sidebar.css"]')) {
      return;
    }
    var link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = sidebarCssHref();
    link.setAttribute("data-dash-sidebar", "1");
    document.head.appendChild(link);
  }

  function logoSrc(pageRoot) {
    var root = pageRoot || document;
    var img =
      root.querySelector("header .brandLogo") ||
      root.querySelector(".dash-header-logo-btn .brandLogo") ||
      document.querySelector(".dash-page header .brandLogo");
    if (img && img.getAttribute("src")) return img.getAttribute("src");
    if (inDashboardsFolder()) return "../assets/fda-logo.png";
    return "assets/fda-logo.png";
  }

  function afterSidebarToggle() {
    window.dispatchEvent(new Event("resize"));
    if (window.mapObj && window.mapObj.invalidateSize) window.mapObj.invalidateSize(true);
    var frame = document.getElementById("dashContentFrame");
    if (frame && frame.contentWindow) {
      try {
        frame.contentWindow.dispatchEvent(new Event("resize"));
        if (frame.contentWindow.dashLayoutResize) frame.contentWindow.dashLayoutResize();
        if (frame.contentWindow.mapObj && frame.contentWindow.mapObj.invalidateSize) {
          frame.contentWindow.mapObj.invalidateSize(true);
        }
      } catch (e) {}
    }
  }

  function setCollapsed(collapsed) {
    document.body.classList.toggle("dash-sidebar-collapsed", collapsed);
    var btn = document.querySelector(".dash-header-logo-btn");
    if (btn) {
      btn.setAttribute("aria-expanded", collapsed ? "false" : "true");
      btn.setAttribute("title", collapsed ? "คลิกโลโก้เพื่อแสดงเมนู" : "คลิกโลโก้เพื่อซ่อนเมนู");
    }
    try {
      localStorage.setItem(STORAGE_KEY, collapsed ? "1" : "0");
    } catch (e) {}
    syncSidebarAria();
    afterSidebarToggle();
    if (window.dashLayoutResize) window.dashLayoutResize();
  }

  function syncSidebarAria() {
    var aside = document.querySelector(".dash-sidebar");
    if (!aside) return;
    var collapsed = document.body.classList.contains("dash-sidebar-collapsed");
    aside.setAttribute("aria-hidden", collapsed ? "true" : "false");
  }

  function setActiveNav(num) {
    var aside = document.querySelector(".dash-sidebar");
    if (!aside) return;
    aside.querySelectorAll(".dash-sidebar-link").forEach(function (a) {
      var n = dashNumFromHref(a.getAttribute("href"));
      a.classList.toggle("active", n === num);
    });
    document.body.setAttribute("data-dash", String(num));
  }

  function toggleSidebar() {
    setCollapsed(!document.body.classList.contains("dash-sidebar-collapsed"));
  }

  function buildSidebar(activeNum, pageRoot) {
    var aside = document.createElement("aside");
    aside.className = "dash-sidebar";
    aside.setAttribute("aria-label", "เมนูแดชบอร์ด");
    aside.setAttribute("aria-hidden", "true");

    var head = document.createElement("div");
    head.className = "dash-sidebar-head";
    head.innerHTML =
      '<img class="dash-sidebar-logo-img" src="' +
      logoSrc(pageRoot) +
      '" alt="อย." onerror="this.style.display=\'none\'">' +
      '<div class="dash-sidebar-org">สำนักงานคณะกรรมการอาหารและยา<br>กระทรวงสาธารณสุข</div>';
    aside.appendChild(head);

    var nav = document.createElement("nav");
    nav.className = "dash-sidebar-nav";
    nav.innerHTML = '<div class="dash-sidebar-label">แดชบอร์ด · 4.3.4.3</div>';

    DASH_ITEMS.forEach(function (item) {
      var a = document.createElement("a");
      a.className = "dash-sidebar-link" + (item.n === activeNum ? " active" : "");
      a.href = hrefForDash(item.n);
      a.setAttribute("data-dash-n", String(item.n));
      a.innerHTML = '<span class="num">' + item.n + "</span><span>" + item.label + "</span>";
      nav.appendChild(a);
    });
    aside.appendChild(nav);

    if (isShell()) wireShellNav(aside);
    else wireSmoothNav(aside);
    return aside;
  }

  function wireShellNav(aside) {
    var frame = document.getElementById("dashContentFrame");
    if (!frame) return;

    aside.addEventListener("click", function (e) {
      var a = e.target.closest(".dash-sidebar-link");
      if (!a) return;
      e.preventDefault();
      var href = a.getAttribute("href");
      var num = dashNumFromHref(href);
      if (!num || a.classList.contains("active")) return;

      setActiveNav(num);
      location.hash = "dash" + num;

      frame.classList.add("dash-frame-loading");
      var onLoad = function () {
        frame.classList.remove("dash-frame-loading");
        frame.removeEventListener("load", onLoad);
        afterSidebarToggle();
      };
      frame.addEventListener("load", onLoad);
      frame.src = href;
    });
  }

  function wireSmoothNav(aside) {
    aside.addEventListener("click", function (e) {
      var a = e.target.closest(".dash-sidebar-link");
      if (!a || a.classList.contains("active")) return;
      var href = a.getAttribute("href");
      if (!href || /^https?:\/\//i.test(href)) return;
      e.preventDefault();
      var page = document.querySelector(".dash-page");
      var go = function () {
        location.href = href;
      };
      if (!page || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
        go();
        return;
      }
      page.classList.add("dash-page-exiting");
      setTimeout(go, 240);
    });
  }

  function mountBackdrop() {
    var bd = document.createElement("button");
    bd.type = "button";
    bd.className = "dash-sidebar-backdrop";
    bd.setAttribute("aria-label", "ปิดเมนู");
    bd.addEventListener("click", function () {
      setCollapsed(true);
    });
    document.body.appendChild(bd);
  }

  function wireHeaderLogoToggle() {
    var img = document.querySelector(".dash-page header .brandLogo");
    if (!img || img.closest(".dash-header-logo-btn")) return;

    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = "dash-header-logo-btn";
    btn.setAttribute("aria-expanded", "false");
    btn.setAttribute("title", "คลิกโลโก้เพื่อแสดงเมนู");

    var parent = img.parentNode;
    parent.insertBefore(btn, img);
    btn.appendChild(img);

    btn.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();
      toggleSidebar();
    });

    var oldToggle = document.getElementById("dashSidebarToggle");
    if (oldToggle) oldToggle.remove();
  }

  function initShell() {
    ensureStyles();
    var active = detectDashNum();
    var frame = document.getElementById("dashContentFrame");
    var body = document.body;

    body.insertBefore(buildSidebar(active, null), frame);
    body.classList.add("dash-with-sidebar");

    mountBackdrop();

    if (frame) {
      frame.src = hrefForDash(active);
      frame.addEventListener("load", afterSidebarToggle);
    }

    setActiveNav(active);
    suppressHashNav = true;
    if (location.hash !== "#dash" + active) location.hash = "dash" + active;
    suppressHashNav = false;

    window.addEventListener("hashchange", function () {
      if (suppressHashNav) return;
      var n = dashNumFromHash();
      if (!frame) return;
      var href = hrefForDash(n);
      if (dashNumFromHref(frame.src) === n) {
        setActiveNav(n);
        return;
      }
      setActiveNav(n);
      frame.classList.add("dash-frame-loading");
      frame.src = href;
    });

    window.addEventListener("message", function (e) {
      if (e && e.data === "fda-dash-toggle-sidebar") toggleSidebar();
    });

    try {
      var stored = localStorage.getItem(STORAGE_KEY);
      if (stored === "1") setCollapsed(true);
      else setCollapsed(false);
    } catch (e2) {
      setCollapsed(false);
    }
  }

  function initStandalone() {
    ensureStyles();
    var active = detectDashNum();
    var page = document.createElement("div");
    page.className = "dash-page";
    var body = document.body;
    while (body.firstChild) page.appendChild(body.firstChild);
    body.appendChild(buildSidebar(active, page));
    body.appendChild(page);
    body.classList.add("dash-with-sidebar");
    body.classList.add("dash-sidebar-collapsed");

    mountBackdrop();
    wireHeaderLogoToggle();

    try {
      var stored = localStorage.getItem(STORAGE_KEY);
      if (stored === "0") setCollapsed(false);
      else setCollapsed(true);
    } catch (e2) {
      setCollapsed(true);
    }
  }

  function init() {
    if (isShell()) initShell();
    else initStandalone();
  }

  window.fdaDashShell = {
    setActiveNav: setActiveNav,
    toggleSidebar: toggleSidebar,
  };

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
