/* โหลดหลัง chart.js และก่อน inline script ของหน้า — กราฟไม่ต้องโตจากศูนย์ 1 วินาทีทุกครั้งที่เปลี่ยนหน้า */
if (window.Chart) Chart.defaults.animation.duration = 300;
